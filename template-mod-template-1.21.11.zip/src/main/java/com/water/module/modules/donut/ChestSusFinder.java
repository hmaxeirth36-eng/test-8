package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Sus Chunk based on chests / barrels / hoppers / shulkers / redstone / spawners
 * below or equal to scanY (default -1).
 */
public final class ChestSusFinder extends Module {
   public static ChestSusFinder INSTANCE;

   public final Setting<Integer> scanRadius = new Setting<>("Scan Radius", 2, 1, 8);
   public final Setting<Integer> scanY = new Setting<>("Max Y", -1, -64, 64);
   public final Setting<Integer> minScore = new Setting<>("Min Score", 10, 1, 50);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(255, 80, 40, 50));
   public final Setting<Integer> fillAlpha = new Setting<>("Fill Alpha", 50, 0, 255);
   public final Setting<Boolean> showInfo = new Setting<>("Show % & Tags", true);
   public final Setting<Boolean> showOutline = new Setting<>("Outline", true);

   public static final class Hit {
      public final int chests;
      public final int redstone;
      public final int spawners;
      public final int percent;
      public final String tag;

      public Hit(int chests, int redstone, int spawners) {
         this.chests = chests;
         this.redstone = redstone;
         this.spawners = spawners;
         int score = chests * 12 + redstone * 2 + spawners * 30;
         this.percent = Math.min(100, score);
         StringBuilder sb = new StringBuilder();
         if (spawners > 0) sb.append("S").append(spawners);
         if (chests > 0) {
            if (sb.length() > 0) sb.append(" ");
            sb.append("C").append(chests);
         }
         if (redstone > 0) {
            if (sb.length() > 0) sb.append(" ");
            sb.append("R").append(redstone);
         }
         this.tag = sb.toString();
      }
   }

   public final Map<ChunkPos, Hit> hits = new ConcurrentHashMap<>();
   public volatile Map<ChunkPos, Hit> renderCache = Collections.emptyMap();
   public ExecutorService scanExec;
   public final AtomicBoolean scanning = new AtomicBoolean(false);
   public int tickCount = 0;
   private final ProjectedPoint projected = new ProjectedPoint();

   public ChestSusFinder() {
      super("Chest Sus Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.scanRadius);
      this.addSetting(this.scanY);
      this.addSetting(this.minScore);
      this.addSetting(this.fillColor);
      this.addSetting(this.fillAlpha);
      this.addSetting(this.showInfo);
      this.addSetting(this.showOutline);
   }

   @Override
   public void onEnable() {
      this.clearState();
   }

   @Override
   public void onDisable() {
      this.clearState();
      if (this.scanExec != null) this.scanExec.shutdownNow();
   }

   public void clearState() {
      this.hits.clear();
      this.renderCache = Collections.emptyMap();
      this.tickCount = 0;
      this.scanning.set(false);
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;

      ChunkPos origin = mc.player.getChunkPos();
      int radius = this.scanRadius.getValue();

      this.hits.entrySet().removeIf(e ->
         Math.abs(e.getKey().x - origin.x) > radius + 2 || Math.abs(e.getKey().z - origin.z) > radius + 2);

      if (++this.tickCount % 10 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.scanExec == null || this.scanExec.isShutdown()) {
         this.scanExec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "chest-sus-scan");
            t.setDaemon(true);
            return t;
         });
      }

      List<ChunkPos> positions = new ArrayList<>();
      List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }

      int maxY = this.scanY.getValue();
      int threshold = this.minScore.getValue();

      this.scanExec.submit(() -> {
         try {
            ConcurrentHashMap<ChunkPos, Hit> next = new ConcurrentHashMap<>();
            for (int i = 0; i < positions.size(); i++) {
               Hit hit = scanChunk(chunks.get(i), maxY);
               if (hit != null && hit.percent >= threshold) {
                  next.put(positions.get(i), hit);
               }
            }
            this.hits.clear();
            this.hits.putAll(next);
            // Replace render cache atomically — keeps previous frame stable until ready
            this.renderCache = Collections.unmodifiableMap(next);
         } catch (Exception ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private Hit scanChunk(WorldChunk chunk, int maxY) {
      int chests = 0, redstone = 0, spawners = 0;
      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int s = 0; s < sections.length; s++) {
         int sectionY = bottom + s * 16;
         if (sectionY > maxY) break;
         ChunkSection section = sections[s];
         if (section == null || section.isEmpty()) continue;

         int localMaxY = Math.min(15, maxY - sectionY);
         if (localMaxY < 0) continue;

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               for (int y = 0; y <= localMaxY; y++) {
                  BlockState state = section.getBlockState(x, y, z);
                  if (state.isOf(Blocks.SPAWNER)) spawners++;
                  else if (isStorage(state)) chests++;
                  else if (isRedstone(state)) redstone++;
               }
            }
         }
      }
      if (chests == 0 && redstone == 0 && spawners == 0) return null;
      return new Hit(chests, redstone, spawners);
   }

   private static boolean isStorage(BlockState state) {
      if (state.isOf(Blocks.CHEST) || state.isOf(Blocks.TRAPPED_CHEST)) return true;
      if (state.isOf(Blocks.BARREL) || state.isOf(Blocks.HOPPER)) return true;
      if (state.isOf(Blocks.DROPPER) || state.isOf(Blocks.DISPENSER)) return true;
      return state.getBlock() instanceof ShulkerBoxBlock;
   }

   private static boolean isRedstone(BlockState state) {
      return state.isOf(Blocks.REDSTONE_WIRE)
         || state.isOf(Blocks.REPEATER)
         || state.isOf(Blocks.COMPARATOR)
         || state.isOf(Blocks.REDSTONE_TORCH)
         || state.isOf(Blocks.REDSTONE_WALL_TORCH)
         || state.isOf(Blocks.REDSTONE_BLOCK)
         || state.isOf(Blocks.PISTON)
         || state.isOf(Blocks.STICKY_PISTON)
         || state.isOf(Blocks.OBSERVER)
         || state.isOf(Blocks.TARGET)
         || state.isOf(Blocks.NOTE_BLOCK)
         || state.isOf(Blocks.DAYLIGHT_DETECTOR);
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world == null || mc.player == null) return;
      Map<ChunkPos, Hit> cache = this.renderCache;
      if (cache.isEmpty()) return;

      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);

      int maxY = this.scanY.getValue();
      double y1 = Math.min(maxY, mc.world.getBottomY() + 1) - cam.y;
      double y2 = maxY + 1.0 - cam.y;

      Color base = this.fillColor.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), this.fillAlpha.getValue());
      Color outline = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, this.fillAlpha.getValue() + 120));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);

      for (ChunkPos cp : cache.keySet()) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y1, z1, x1 + 16.0, y2, z1 + 16.0, fill);
         if (this.showOutline.getValue()) {
            batch.renderOutlineBox(x1, y1, z1, x1 + 16.0, y2, z1 + 16.0, outline);
         }
      }

      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      ChestSusFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showInfo.getValue()) return;
      Map<ChunkPos, Hit> cache = self.renderCache;
      if (cache.isEmpty()) return;

      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null || mc.world == null) return;

      double textY = self.scanY.getValue() + 2.5;

      for (Map.Entry<ChunkPos, Hit> e : cache.entrySet()) {
         ChunkPos cp = e.getKey();
         Hit hit = e.getValue();
         double worldX = (cp.x << 4) + 8.0;
         double worldZ = (cp.z << 4) + 8.0;

         if (!Render3D.projectToPoint(Render3D.modelViewMatrix, Render3D.projectionMatrix, worldX, textY, worldZ, self.projected)) {
            continue;
         }
         if (!self.projected.visible) continue;

         String line1 = hit.percent + "%";
         String line2 = hit.tag.isEmpty() ? "BASE" : hit.tag;
         // marker icon as text prefix
         String marker = "\u26A0 "; // warning sign

         float x = (float) self.projected.x;
         float y = (float) self.projected.y;

         int w1 = FontRenderer.INSTANCE.getWidth(marker + line1);
         int w2 = FontRenderer.INSTANCE.getWidth(line2);

         int color = hit.percent >= 70 ? 0xFFFF5555 : (hit.percent >= 40 ? 0xFFFFAA00 : 0xFF55FF55);

         // stable shadow + text (no alpha animation to avoid flicker)
         FontRenderer.INSTANCE.drawString(context, marker + line1, x - w1 / 2f + 1, y + 1, 0xFF000000);
         FontRenderer.INSTANCE.drawString(context, marker + line1, x - w1 / 2f, y, color);
         FontRenderer.INSTANCE.drawString(context, line2, x - w2 / 2f + 1, y + 11, 0xFF000000);
         FontRenderer.INSTANCE.drawString(context, line2, x - w2 / 2f, y + 10, 0xFFFFFFFF);
      }
   }
}
